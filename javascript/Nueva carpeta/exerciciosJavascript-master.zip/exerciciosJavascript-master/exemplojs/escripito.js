/* 
	Exemplo ficheiro (a completar) en JavaScript
	Nome do ficheiro: escripito.js
	 
*/

