<img src="https://irocho.files.wordpress.com/2012/10/rocho-950x264-e1350378609633.png">

# Repositorio de exercicios de Javascript
Código para ir programando en JavaScript

_empregado en AppWeb de SMR_
